File includes:

list.h
list.c //linked list file
hash.h
hash.c //hash table file
mainFunction.h
mainFunction.c //helper function to the main
main.c //main function and some helper functions

Compile the program using: gcc -Wall -g -std=c99 list.c hash.c mainFunction.c main.c

The program should be executed as: ./a.out -f First_File_Name -s Second_File_name
If not entered correctly, error message will be reported.
